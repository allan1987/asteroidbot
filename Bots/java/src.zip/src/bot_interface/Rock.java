package bot_interface;

public class Rock extends GameObject {

	Rock(int uid) {
		super(uid);
	}

}
